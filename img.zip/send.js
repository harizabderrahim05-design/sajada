// سكريبت إرسال بيانات النموذج إلى Google Apps Script مباشرة من المتصفح

document.getElementById('Order_Form').addEventListener('submit', function(e) {
  e.preventDefault();
  var form = e.target;
  var data = new FormData(form);

  fetch('https://script.google.com/macros/s/AKfycbzjYIlQI2XEfMMKia32i71HKORURjQMg5Fx5jimLi2R1ywD1lDotu1f6w4UJJDbw3I/exec', {
    method: 'POST',
    body: data
  })
  .then(response => response.text())
  .then(result => {
    // يمكنك هنا عرض رسالة نجاح أو إعادة التوجيه
    alert(result);
    // window.location.href = "thankyou.html";
  })
  .catch(error => {
    alert('حدث خطأ أثناء إرسال الطلب.');
  });
});
